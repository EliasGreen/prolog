﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TrivialBehind;

namespace ScfProjectDesign
{
    public partial class ScfProjectForm: Form
    {
        public ScfProjectForm()
        {
            InitializeComponent();
            // boilerplate starts
            var disposer = TrivialBehinds.CreateBehind(this, new ScfProjectUi
            {
                button1 = button1,
                label1 = label1,
                richTextBox1 = richTextBox1,
                richTextBox2 = richTextBox2,
                richTextBox3 = richTextBox3,
                richTextBox4 = richTextBox4
            });
            this.FormClosed += (o,e) => 
                disposer.Dispose();
            // boilerplate ends

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
