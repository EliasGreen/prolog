﻿using System.Windows.Forms;

namespace ScfProjectDesign
{
    public class ScfProjectUi
    {
        public Button button1;
        public Label label1;
        public RichTextBox richTextBox1;
        public RichTextBox richTextBox2;
        public RichTextBox richTextBox3;
        public RichTextBox richTextBox4;
    }
}
