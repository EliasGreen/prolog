﻿module ScfProject.Main

open System
open System.Windows.Forms
open ScfProjectDesign

open TrivialBehind

let solve a b c =
  let D = b*b-4.*a*c in
  [(+);(-)] |> List.map (fun f -> (f -b (sqrt D))/2./a)

type ScfProjectBehind(ui: ScfProjectUi) = 
    do
        ui.button1.Click.Add <| fun _ ->
            //result <- solve (ui.richTextBox2.Text |> int) (ui.richTextBox3.Text |> int) (ui.richTextBox4.Text |> int)
            let a = ui.richTextBox2.Text |> float
            let b = ui.richTextBox3.Text |> float
            let c = ui.richTextBox4.Text |> float
            printf "%f\n" a
            printf "%f\n" b
            printf "%f\n" c
            let result = solve a b c
            if result |> string = "[NaN; NaN]" then ui.richTextBox1.Text <- sprintf "Действительных корнем нет"
            else ui.richTextBox1.Text <- sprintf "%s" (result |> string)


let registerBehinds() =
    TrivialBehinds.RegisterBehind<ScfProjectUi, ScfProjectBehind>()
    

[<EntryPoint; STAThread>]
let main argv =
    Application.EnableVisualStyles()
    Application.SetCompatibleTextRenderingDefault(false)
    registerBehinds()
    use form = new ScfProjectForm()
    Application.Run(form)    
    0 // return an integer exit code
